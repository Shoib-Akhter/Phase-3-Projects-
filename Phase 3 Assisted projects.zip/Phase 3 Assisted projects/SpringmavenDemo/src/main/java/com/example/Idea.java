package com.example;

public class Idea implements Sim {

	@Override
	public void typeOfSim() {
		System.out.println("this is an idea sim ");
		
	}

	@Override
	public void dataTypeOfSim() {
		System.out.println(" this supports a 4G data ");
		
	}

}
