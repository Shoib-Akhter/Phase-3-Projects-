package com.example;

public interface Sim {
	public void typeOfSim();
	public void dataTypeOfSim();

}
